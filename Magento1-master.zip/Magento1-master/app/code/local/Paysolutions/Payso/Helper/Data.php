<?php

class Paysolutions_Payso_Helper_Data extends Mage_Core_Helper_Abstract
{

}//end class Paysolutions_Payso_Helper_Data