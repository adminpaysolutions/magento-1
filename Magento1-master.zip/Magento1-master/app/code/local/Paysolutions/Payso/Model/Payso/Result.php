<?php

class Paysolutions_Payso_Model_Payso_Result extends Varien_Object 
{
    
}//end class Paysolutions_Payso_Model_Payso_Result
