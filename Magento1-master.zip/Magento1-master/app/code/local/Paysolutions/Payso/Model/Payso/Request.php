<?php

class Paysolutions_Payso_Model_Payso_Request extends Varien_Object 
{
    
}//end class Paysolutions_Payso_Model_Payso_Request
